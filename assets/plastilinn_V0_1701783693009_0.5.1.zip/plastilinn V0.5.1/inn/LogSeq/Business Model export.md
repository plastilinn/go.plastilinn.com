## 1 Copy content
	- #inn-edit
		- {{embed [[business model]]}}
- ## 2 Paste it on a markdown editor
	- such as https://stackedit.io/app#
- ## 3 Copy paste formatted content
- ## Export model
	- [[Export to text]]