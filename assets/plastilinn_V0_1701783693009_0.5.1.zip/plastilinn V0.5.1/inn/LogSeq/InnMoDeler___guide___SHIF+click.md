color:: grey
alias:: shiftclick

- # Open a page link on the right panel
- ![InnMoDelerguideSHIF+click.gif](../assets/InnMoDelerguideSHIF+click_1695305683992_0.gif)
- ### 1 Hold down the SHIFT key
- ### 2 Click [[InnMoDeler/guide/SHIF+click example page]]
-