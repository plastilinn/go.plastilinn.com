icon:: ⚙️

- {{query (and [[TODO]] [[A]])}}