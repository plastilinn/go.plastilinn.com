icon:: ⛏️

- #minimal-query
  #+BEGIN_QUERY
  { :query (and (task NOW LATER DOING IN-PROGRESS TODO WAIT WAITING) [[business info]])
  }
  #+END_QUERY