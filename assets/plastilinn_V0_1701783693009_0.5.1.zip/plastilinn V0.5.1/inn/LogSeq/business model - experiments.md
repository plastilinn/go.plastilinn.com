- {{embed [[plastilinn console menu]]}}
- #+BEGIN_QUERY
  { :query (and [[experiment list]] "#experiment")
  :breadcrumb-show? true
  :collapse? false
  }
  #+END_QUERY