- {{embed [[plastilinn console menu]]}}
- #minimal-query
  #+BEGIN_QUERY
  { :query (and (and [[business model]] "#artifact") (not "#pending"))
  :breadcrumb-show? false
  }
  #+END_QUERY