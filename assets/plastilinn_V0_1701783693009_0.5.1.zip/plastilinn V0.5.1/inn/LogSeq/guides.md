icon:: 📋
color:: grey

-
- #guide [[Opportunity development]]