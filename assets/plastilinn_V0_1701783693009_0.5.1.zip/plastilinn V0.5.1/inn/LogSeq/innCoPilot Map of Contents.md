# What do you want to do?
- ### [Getting started with innCoPilot](innCoPilot/docs)
- ### [Define my business step by step](master guide)
- ### [Apprise the success chance of my business]([[keys (weight)]])
- ### [Identify the main risks of my business](risk list)