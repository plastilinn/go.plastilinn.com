color:: grey

-
- Servidor de Discord que te permitirá:
	- Hacer preguntas Sobre el funcionamiento de innCoPilot y obtener respuestas
	- Apuntarte a grupos de innovadores en áreas o con proyectos similares al tuyo y compartir conocimiento
	- Encontrar otros innovadores con los que intercambiar feedback
	- Interactuar con expertos en áreas determinadas y contratar sesiones de asesoría