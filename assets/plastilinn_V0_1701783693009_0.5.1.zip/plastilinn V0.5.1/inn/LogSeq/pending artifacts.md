- {{embed [[plastilinn console menu]]}}
- #minimal-query
  query-table:: false
  #+BEGIN_QUERY
  { :query (and (and [[business model]] "#artifact") "#pending")
  :breadcrumb-show? false
  }
  #+END_QUERY