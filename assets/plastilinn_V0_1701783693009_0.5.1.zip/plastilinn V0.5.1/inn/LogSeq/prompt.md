alias::  prompts
icon:: 🤖

-