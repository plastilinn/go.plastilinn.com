icon:: 🧿
version::  0.1.0

- {{embed [[plastilinn console menu]]}}
- ### #item [[my business]] 
  innbok-item-type:: my-business
  collapsed:: true
  - [help](https://go.innbok.com/#/page/my-business%2Finfo)
  - #### #artifact [[my business]] [[*****]] #pending
    - #placeholder
    - #minimal-query
      #+BEGIN_QUERY
      {:query (and [[business info]] "# my-business")
      :breadcrumb-show? false
      }
      #+END_QUERY
  - #### #keys
      - #key [[my-business/Continuous innovation and adaptation]] [[***]] [[-+]]
        key-weight:: 50
      - #key [[my-business/Robust fraud prevention measures]] [[*]] [[-+]]
        key-weight:: 20
      - #key [[my-business/Stable political environment]] [[*]] [[-+]]
        key-weight:: 10
    - ### #item [[opportunity]] 
      innbok-item-type:: opportunity
      collapsed:: true
      - [help](https://go.innbok.com/#/page/opportunity%2Finfo)
      - #### #artifact [[opportunity]] [[**]] #pending
        - #placeholder
        - #minimal-query
          #+BEGIN_QUERY
          {:query (and [[business info]] "# opportunity")
          :breadcrumb-show? false
          }
          #+END_QUERY
      - #### #keys
          - #key [[opportunity/Momentum]] [[***]] [[-+]]
            key-weight:: 60
          - #key [[opportunity/Innovative approach]] [[**]] [[-+]]
            key-weight:: 40
          - #key [[opportunity/Evolution potential]] [[**]] [[-+]]
            key-weight:: 30
          - #key [[opportunity/Business obviousness]] [[*]] [[-+]]
            key-weight:: 20
  - ### #item [[stakeholders]] 
    innbok-item-type:: stakeholders
    collapsed:: true
    - [help](https://go.innbok.com/#/page/stakeholders%2Finfo)
    - #### #artifact [[stakeholders]] [[****]] #pending
      - #segment name
  
      - #minimal-query
        #+BEGIN_QUERY
        {:query (and [[business info]] "# stakeholders")
        :breadcrumb-show? false
        }
        #+END_QUERY
    - #### #keys
        
  - ### #item [[profile list]] 
    innbok-item-type:: profile-list
    collapsed:: true
    - [help](https://go.innbok.com/#/page/profile-list%2Finfo)
    - #### #artifact [[profile list]] [[***]] #pending
      - #placeholder
      - #minimal-query
        #+BEGIN_QUERY
        {:query (and [[business info]] "# profile-list")
        :breadcrumb-show? false
        }
        #+END_QUERY
    - #### #keys
        
    - {{renderer :smartblock, profile (id) template, New profile (id), true}}
  - ### #item [[solution list]] 
    innbok-item-type:: solution-list
    collapsed:: true
    - [help](https://go.innbok.com/#/page/solution-list%2Finfo)
    - #### #artifact [[solution list]] [[****]] #pending
      - #solution name
  
      - #minimal-query
        #+BEGIN_QUERY
        {:query (and [[business info]] "# solution-list")
        :breadcrumb-show? false
        }
        #+END_QUERY
    - #### #keys
        - #key [[solution-list/Efficient product development process]] [[**]] [[-+]]
          key-weight:: 40
        - #key [[solution-list/Use of Technology]] [[**]] [[-+]]
          key-weight:: 40
        - #key [[solution-list/Information Security]] [[**]] [[-+]]
          key-weight:: 40
        - #key [[solution-list/Technological Adaptability]] [[**]] [[-+]]
          key-weight:: 30
    - {{renderer :smartblock, solution (id) template, New solution (id), true}}
  - ### #item [[team]] 
    innbok-item-type:: team
    collapsed:: true
    - [help](https://go.innbok.com/#/page/team%2Finfo)
    - #### #artifact [[team]] [[****]] #pending
      - #placeholder
      - #minimal-query
        #+BEGIN_QUERY
        {:query (and [[business info]] "# team")
        :breadcrumb-show? false
        }
        #+END_QUERY
    - #### #keys
        - #key [[team/Team Skills]] [[****]] [[-+]]
          key-weight:: 70
        - #key [[team/Team Commitment]] [[***]] [[-+]]
          key-weight:: 60
        - #key [[team/Adaptability to Change]] [[***]] [[-+]]
          key-weight:: 55
        - #key [[team/Team alignment]] [[***]] [[-+]]
          key-weight:: 50
        - #key [[team/Effective talent acquisition and retention]] [[***]] [[-+]]
          key-weight:: 50
        - #key [[team/Culture of Experimentation]] [[***]] [[-+]]
          key-weight:: 50
        - #key [[team/Human Resource Management]] [[***]] [[-+]]
          key-weight:: 45
        - #key [[team/Talent Retention]] [[**]] [[-+]]
          key-weight:: 35
        - #key [[team/Work Environment]] [[**]] [[-+]]
          key-weight:: 30
        - #key [[team/Team composition]] [[**]] [[-+]]
          key-weight:: 30
        - #key [[team/Benefits and Compensation]] [[*]] [[-+]]
          key-weight:: 20
        - #key [[team/Employee Development]] [[*]] [[-+]]
          key-weight:: 20
    - ### #item [[people]] 
      innbok-item-type:: people
      collapsed:: true
      - [help](https://go.innbok.com/#/page/people%2Finfo)
      - #### #artifact [[people]] [[****]] #pending
        - #person name
    
        - #minimal-query
          #+BEGIN_QUERY
          {:query (and [[business info]] "# people")
          :breadcrumb-show? false
          }
          #+END_QUERY
      - #### #keys
          - #key [[people/Receptiveness to Feedback]] [[**]] [[-+]]
            key-weight:: 40
          - #key [[people/Competency scope]] [[**]] [[-+]]
            key-weight:: 40
          - #key [[people/Relevant experience]] [[**]] [[-+]]
            key-weight:: 30
          - #key [[people/Market experience]] [[**]] [[-+]]
            key-weight:: 25
          - #key [[people/Skills and expectations overlap]] [[**]] [[-+]]
            key-weight:: 25
          - #key [[people/Vertical experience]] [[*]] [[-+]]
            key-weight:: 15
          - #key [[people/Experience working together]] [[*]] [[-+]]
            key-weight:: 10
      - {{renderer :smartblock, person (id) template, New person (id), true}}
  - ### #item [[analysis]] 
    innbok-item-type:: analysis
    collapsed:: true
    - [help](https://go.innbok.com/#/page/analysis%2Finfo)
    - #### #artifact [[analysis]] [[****]] #pending
      - #placeholder
      - #minimal-query
        #+BEGIN_QUERY
        {:query (and [[business info]] "# analysis")
        :breadcrumb-show? false
        }
        #+END_QUERY
    - #### #keys
        
    - ### #item [[key list]] 
      innbok-item-type:: key-list
      collapsed:: true
      - [help](https://go.innbok.com/#/page/key-list%2Finfo)
      - #### #artifact [[key list]] [[****]] #pending
        - #placeholder
        - #minimal-query
          #+BEGIN_QUERY
          {:query (and [[business info]] "# key-list")
          :breadcrumb-show? false
          }
          #+END_QUERY
      - #### #keys
          
    - ### #item [[risk list]] 
      innbok-item-type:: risk-list
      collapsed:: true
      - [help](https://go.innbok.com/#/page/risk-list%2Finfo)
      - #### #artifact [[risk list]] [[*****]] #pending
        - #risk name
    
        - #minimal-query
          #+BEGIN_QUERY
          {:query (and [[business info]] "# risk-list")
          :breadcrumb-show? false
          }
          #+END_QUERY
      - #### #keys
          - #key [[risk-list/Risk Identification]] [[***]] [[-+]]
            key-weight:: 50
          - #key [[risk-list/Crisis Management]] [[**]] [[-+]]
            key-weight:: 30
          - #key [[risk-list/Contingency Plans]] [[*]] [[-+]]
            key-weight:: 20
    - ### #item [[business appraisals]] 
      innbok-item-type:: business-appraisals
      collapsed:: true
      - [help](https://go.innbok.com/#/page/business-appraisals%2Finfo)
      - #### #artifact [[business appraisals]] [[]] #pending
        - #placeholder
        - #minimal-query
          #+BEGIN_QUERY
          {:query (and [[business info]] "# business-appraisals")
          :breadcrumb-show? false
          }
          #+END_QUERY
      - #### #keys
          
  - ### #item [[validation]] 
    innbok-item-type:: validation
    collapsed:: true
    - [help](https://go.innbok.com/#/page/validation%2Finfo)
    - #### #artifact [[validation]] [[*****]] #pending
      - #placeholder
      - #minimal-query
        #+BEGIN_QUERY
        {:query (and [[business info]] "# validation")
        :breadcrumb-show? false
        }
        #+END_QUERY
    - #### #keys
        
    - ### #item [[experiment list]] 
      innbok-item-type:: experiment-list
      collapsed:: true
      - [help](https://go.innbok.com/#/page/experiment-list%2Finfo)
      - #### #artifact [[experiment list]] [[***]] #pending
        - #experiment name
    
        - #minimal-query
          #+BEGIN_QUERY
          {:query (and [[business info]] "# experiment-list")
          :breadcrumb-show? false
          }
          #+END_QUERY
      - #### #keys
          
      - {{renderer :smartblock, experiment (id) template, New experiment (id), true}}
  - ### #item [[references]] 
    innbok-item-type:: references
    collapsed:: true
    - [help](https://go.innbok.com/#/page/references%2Finfo)
    - #### #artifact [[references]] [[]] #pending
      - #placeholder
      - #minimal-query
        #+BEGIN_QUERY
        {:query (and [[business info]] "# references")
        :breadcrumb-show? false
        }
        #+END_QUERY
    - #### #keys
        

