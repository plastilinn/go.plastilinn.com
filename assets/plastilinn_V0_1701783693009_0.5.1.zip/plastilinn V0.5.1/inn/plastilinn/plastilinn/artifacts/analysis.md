innbok-type:: internal
metamodel-id:: [[analysis]]
relations:: [[]]
weight:: 80


- ## [help](https://go.innbok.com/#/page/analysis_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[analysis]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  
- ## Topics
  

