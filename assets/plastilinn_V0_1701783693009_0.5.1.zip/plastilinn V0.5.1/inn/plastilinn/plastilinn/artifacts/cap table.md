innbok-type:: internal
metamodel-id:: [[cap-table]]
relations:: [[]]
weight:: 20


- ## [help](https://go.innbok.com/#/page/cap-table_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[cap table]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  
- ## Topics
  

