innbok-type:: internal
metamodel-id:: [[experiment-list]]
item-classes:: #[[experiment]]
relations:: [[risk list]] [[assumption list]]
weight:: 60


- ## [help](https://go.innbok.com/#/page/experiment-list_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[experiment list]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  
- ## Topics
  - ### TODO #topic topic/Modelo de negocio/Ciclo de modelado de negocio/Validación/Experimentos
    plastilinn-type:: [[topic]] [[guide-item]]
    innbok-artifact:: [[experiment-list]]
    - {{embed [[topic/Modelo de negocio/Ciclo de modelado de negocio/Validación/Experimentos]]}}
  

