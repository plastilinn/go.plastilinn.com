innbok-type:: internal
metamodel-id:: [[function-list]]
item-classes:: #[[function]]
relations:: [[]]
weight:: 30


- ## [help](https://go.innbok.com/#/page/function-list_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[function list]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  
- ## Topics
  

