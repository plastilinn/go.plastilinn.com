innbok-type:: internal
metamodel-id:: [[legal]]
relations:: [[]]
weight:: 40


- ## [help](https://go.innbok.com/#/page/legal_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[legal]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[legal/Strong intellectual property protection]] [[****]] [[-+]]
    key-weight:: 70
  - #key [[legal/Risk Management]] [[***]] [[-+]]
    key-weight:: 60
  - #key [[legal/Legal Compliance]] [[***]] [[-+]]
    key-weight:: 60
  - #key [[legal/Licenses and Permits]] [[***]] [[-+]]
    key-weight:: 60
  - #key [[legal/Protectability]] [[***]] [[-+]]
    key-weight:: 45
  - #key [[legal/Contracts and Agreements]] [[**]] [[-+]]
    key-weight:: 35
  - #key [[legal/Legal complexity]] [[**]] [[-+]]
    key-weight:: 25
  - #key [[legal/Regulatory compliance]] [[*]] [[-+]]
    key-weight:: 20
  - #key [[legal/Intellectual Property]] [[*]] [[-+]]
    key-weight:: 20
- ## Topics
  

