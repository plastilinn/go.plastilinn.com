innbok-type:: internal
metamodel-id:: [[life-time-value]]
relations:: [[]]
weight:: 50


- ## [help](https://go.innbok.com/#/page/life-time-value_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[life time value]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  
- ## Topics
  

