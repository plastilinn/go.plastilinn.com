innbok-type:: internal
metamodel-id:: [[marketing]]
relations:: [[]]
weight:: 40


- ## [help](https://go.innbok.com/#/page/marketing_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[marketing]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[marketing/Effective distribution and marketing channels]] [[****]] [[-+]]
    key-weight:: 70
  - #key [[marketing/Market Demand]] [[****]] [[-+]]
    key-weight:: 65
  - #key [[marketing/Strong reputation management]] [[***]] [[-+]]
    key-weight:: 60
  - #key [[marketing/Marketing Strategy]] [[***]] [[-+]]
    key-weight:: 60
  - #key [[marketing/Barriers to Entry]] [[***]] [[-+]]
    key-weight:: 45
  - #key [[marketing/Comprehensive market research and analysis]] [[**]] [[-+]]
    key-weight:: 30
- ## Topics
  

