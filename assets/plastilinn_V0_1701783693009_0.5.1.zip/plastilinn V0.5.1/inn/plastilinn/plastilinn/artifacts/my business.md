innbok-type:: internal
metamodel-id:: [[my-business]]
relations:: [[]]
weight:: 90


- ## [help](https://go.innbok.com/#/page/my-business_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[my business]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[my-business/Continuous innovation and adaptation]] [[***]] [[-+]]
    key-weight:: 50
  - #key [[my-business/Robust fraud prevention measures]] [[*]] [[-+]]
    key-weight:: 20
  - #key [[my-business/Stable political environment]] [[*]] [[-+]]
    key-weight:: 10
- ## Topics
  - ### TODO #topic topic/Modelo de negocio
    plastilinn-type:: [[topic]] [[guide-item]]
    innbok-artifact:: [[my-business]]
    - {{embed [[topic/Modelo de negocio]]}}
  
  - ### TODO #topic topic/Modelo de negocio/Qué es un modelo
    plastilinn-type:: [[topic]] [[guide-item]]
    innbok-artifact:: [[my-business]]
    - {{embed [[topic/Modelo de negocio/Qué es un modelo]]}}
  
  - ### TODO #topic topic/Modelo de negocio/Qué es un negocio
    plastilinn-type:: [[topic]] [[guide-item]]
    innbok-artifact:: [[my-business]]
    - {{embed [[topic/Modelo de negocio/Qué es un negocio]]}}
  
  - ### TODO #topic topic/Modelo de negocio/Por qué es importante crear un modelo de negocio
    plastilinn-type:: [[topic]] [[guide-item]]
    innbok-artifact:: [[my-business]]
    - {{embed [[topic/Modelo de negocio/Por qué es importante crear un modelo de negocio]]}}
  
  - ### TODO #topic topic/Modelo de negocio/Herramientas y artefactos de modelado de negocio
    plastilinn-type:: [[topic]] [[guide-item]]
    innbok-artifact:: [[my-business]]
    - {{embed [[topic/Modelo de negocio/Herramientas y artefactos de modelado de negocio]]}}
  
  - ### TODO #topic topic/Modelo de negocio/Ciclo de modelado de negocio
    plastilinn-type:: [[topic]] [[guide-item]]
    innbok-artifact:: [[my-business]]
    - {{embed [[topic/Modelo de negocio/Ciclo de modelado de negocio]]}}
  
  - ### TODO #topic topic/Modelo de negocio/Ciclo de modelado de negocio/Diseño
    plastilinn-type:: [[topic]] [[guide-item]]
    innbok-artifact:: [[my-business]]
    - {{embed [[topic/Modelo de negocio/Ciclo de modelado de negocio/Diseño]]}}
  
  - ### TODO #topic topic/Modelo de negocio/Ciclo de modelado de negocio/Diseño/Componentes
    plastilinn-type:: [[topic]] [[guide-item]]
    innbok-artifact:: [[my-business]]
    - {{embed [[topic/Modelo de negocio/Ciclo de modelado de negocio/Diseño/Componentes]]}}
  
  - ### TODO #topic topic/Modelo de negocio/Ciclo de modelado de negocio/Diseño/Maleabilidad
    plastilinn-type:: [[topic]] [[guide-item]]
    innbok-artifact:: [[my-business]]
    - {{embed [[topic/Modelo de negocio/Ciclo de modelado de negocio/Diseño/Maleabilidad]]}}
  
  - ### TODO #topic topic/Modelo de negocio/Ciclo de modelado de negocio/Diseño/Formato
    plastilinn-type:: [[topic]] [[guide-item]]
    innbok-artifact:: [[my-business]]
    - {{embed [[topic/Modelo de negocio/Ciclo de modelado de negocio/Diseño/Formato]]}}
  
  - ### TODO #topic topic/Modelo de negocio/Ciclo de modelado de negocio/Diseño/Herramientas
    plastilinn-type:: [[topic]] [[guide-item]]
    innbok-artifact:: [[my-business]]
    - {{embed [[topic/Modelo de negocio/Ciclo de modelado de negocio/Diseño/Herramientas]]}}
  
  - ### TODO #topic topic/Modelo de negocio/Ciclo de modelado de negocio/Diseño/Plasmación
    plastilinn-type:: [[topic]] [[guide-item]]
    innbok-artifact:: [[my-business]]
    - {{embed [[topic/Modelo de negocio/Ciclo de modelado de negocio/Diseño/Plasmación]]}}
  
  - ### TODO #topic topic/Modelo de negocio/Ciclo de modelado de negocio/Diseño/Qué es el diseño
    plastilinn-type:: [[topic]] [[guide-item]]
    innbok-artifact:: [[my-business]]
    - {{embed [[topic/Modelo de negocio/Ciclo de modelado de negocio/Diseño/Qué es el diseño]]}}
  
  - ### TODO #topic topic/Modelo de negocio/Ciclo de modelado de negocio/Diseño/Ponderación
    plastilinn-type:: [[topic]] [[guide-item]]
    innbok-artifact:: [[my-business]]
    - {{embed [[topic/Modelo de negocio/Ciclo de modelado de negocio/Diseño/Ponderación]]}}
  
  - ### TODO #topic topic/Modelo de negocio/Ciclo de modelado de negocio/Diseño/Incertidumbre
    plastilinn-type:: [[topic]] [[guide-item]]
    innbok-artifact:: [[my-business]]
    - {{embed [[topic/Modelo de negocio/Ciclo de modelado de negocio/Diseño/Incertidumbre]]}}
  
  - ### TODO #topic topic/Modelo de negocio/Ciclo de modelado de negocio/Análisis
    plastilinn-type:: [[topic]] [[guide-item]]
    innbok-artifact:: [[my-business]]
    - {{embed [[topic/Modelo de negocio/Ciclo de modelado de negocio/Análisis]]}}
  
  - ### TODO #topic topic/Modelo de negocio/Ciclo de modelado de negocio/Análisis/Aplica el pensamiento crítico
    plastilinn-type:: [[topic]] [[guide-item]]
    innbok-artifact:: [[my-business]]
    - {{embed [[topic/Modelo de negocio/Ciclo de modelado de negocio/Análisis/Aplica el pensamiento crítico]]}}
  
  - ### TODO #topic topic/Modelo de negocio/Ciclo de modelado de negocio/Análisis/Claves de negocio
    plastilinn-type:: [[topic]] [[guide-item]]
    innbok-artifact:: [[my-business]]
    - {{embed [[topic/Modelo de negocio/Ciclo de modelado de negocio/Análisis/Claves de negocio]]}}
  
  - ### TODO #topic topic/Modelo de negocio/Ciclo de modelado de negocio/Análisis/Analiza las claves de tu modelo de negocio
    plastilinn-type:: [[topic]] [[guide-item]]
    innbok-artifact:: [[my-business]]
    - {{embed [[topic/Modelo de negocio/Ciclo de modelado de negocio/Análisis/Analiza las claves de tu modelo de negocio]]}}
  

