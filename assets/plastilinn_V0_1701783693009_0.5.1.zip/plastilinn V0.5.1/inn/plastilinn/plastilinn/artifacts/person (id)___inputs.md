innbok-type:: internal
metamodel-id:: [[person-(id)/inputs]]
relations:: [[person (id)]] [[]]
weight:: 50


- ## [help](https://go.innbok.com/#/page/person-%28id%29%2Finputs_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[person (id)/inputs]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  
- ## Topics
  

