innbok-type:: internal
metamodel-id:: [[profile-(id)/goals]]
item-classes:: #[[goal]]
relations:: [[profile (id)]] [[profile (id)/value proposition]] [[profile (id)/segmentation]] [[profile (id)/emotions]]
weight:: 70


- ## [help](https://go.innbok.com/#/page/profile-%28id%29%2Fgoals_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[profile (id)/goals]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[profile-(id)/goals/Addressing a critical problem]] [[****]] [[-+]]
    key-weight:: 80
  - #key [[profile-(id)/goals/Pain perception]] [[****]] [[-+]]
    key-weight:: 70
  - #key [[profile-(id)/goals/Urgency perception]] [[***]] [[-+]]
    key-weight:: 45
  - #key [[profile-(id)/goals/Finantial damage]] [[**]] [[-+]]
    key-weight:: 35
- ## Topics
  

