innbok-type:: internal
metamodel-id:: [[profile-(id)/messages]]
item-classes:: #[[message]]
relations:: [[profile (id)]] [[profile (id)/value proposition]] [[profile (id)/goals]] [[profile (id)/messages]]
weight:: 30


- ## [help](https://go.innbok.com/#/page/profile-%28id%29%2Fmessages_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[profile (id)/messages]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  
- ## Topics
  

