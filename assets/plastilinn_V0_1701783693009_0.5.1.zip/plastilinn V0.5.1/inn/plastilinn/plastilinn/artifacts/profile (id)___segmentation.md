innbok-type:: internal
metamodel-id:: [[profile-(id)/segmentation]]
item-classes:: #[[segmentation]]
relations:: [[profile (id)]] [[segment id___segmentation criteria]]
weight:: 60


- ## [help](https://go.innbok.com/#/page/profile-%28id%29%2Fsegmentation_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[profile (id)/segmentation]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  
- ## Topics
  

