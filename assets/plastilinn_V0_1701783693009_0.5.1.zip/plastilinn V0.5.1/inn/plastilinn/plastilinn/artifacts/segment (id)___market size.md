innbok-type:: internal
metamodel-id:: [[segment-(id)/market-size]]
relations:: [[segment (id)]] [[]]
weight:: 50


- ## [help](https://go.innbok.com/#/page/segment-%28id%29%2Fmarket-size_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[segment (id)/market size]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[segment-(id)/market-size/Market Size]] [[****]] [[-+]]
    key-weight:: 65
  - #key [[segment-(id)/market-size/Growth Potential]] [[***]] [[-+]]
    key-weight:: 50
- ## Topics
  

