innbok-type:: internal
metamodel-id:: [[segment-(id)/profiles]]
item-classes:: #[[profile]]
relations:: [[segment (id)]] [[]]
weight:: 20


- ## [help](https://go.innbok.com/#/page/segment-%28id%29%2Fprofiles_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[segment (id)/profiles]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  
- ## Topics
  

