innbok-type:: internal
metamodel-id:: [[solution-(id)]]
relations:: [[business]] [[opportunity]]
weight:: 60


- ## [help](https://go.innbok.com/#/page/solution-%28id%29_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[solution (id)]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[solution-(id)/Product-Market Fit]] [[****]] [[-+]]
    key-weight:: 70
  - #key [[solution-(id)/Solution efficiency]] [[***]] [[-+]]
    key-weight:: 55
  - #key [[solution-(id)/Effective solution]] [[***]] [[-+]]
    key-weight:: 50
  - #key [[solution-(id)/Financial benefits]] [[***]] [[-+]]
    key-weight:: 45
  - #key [[solution-(id)/Ease of Use]] [[***]] [[-+]]
    key-weight:: 45
  - #key [[solution-(id)/Product Quality]] [[**]] [[-+]]
    key-weight:: 40
  - #key [[solution-(id)/Agility]] [[**]] [[-+]]
    key-weight:: 40
  - #key [[solution-(id)/Robust product quality control]] [[**]] [[-+]]
    key-weight:: 35
  - #key [[solution-(id)/Product focus]] [[**]] [[-+]]
    key-weight:: 30
- ## Topics
  

