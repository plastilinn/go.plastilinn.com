innbok-type:: internal
metamodel-id:: [[solution-list]]
item-classes:: #[[solution]]
relations:: [[my business]] [[opportunity]]
weight:: 70


- ## [help](https://go.innbok.com/#/page/solution-list_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[solution list]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[solution-list/Efficient product development process]] [[**]] [[-+]]
    key-weight:: 40
  - #key [[solution-list/Use of Technology]] [[**]] [[-+]]
    key-weight:: 40
  - #key [[solution-list/Information Security]] [[**]] [[-+]]
    key-weight:: 40
  - #key [[solution-list/Technological Adaptability]] [[**]] [[-+]]
    key-weight:: 30
- ## Topics
  

