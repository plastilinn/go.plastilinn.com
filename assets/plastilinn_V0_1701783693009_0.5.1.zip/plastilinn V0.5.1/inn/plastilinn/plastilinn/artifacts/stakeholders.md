innbok-type:: internal
metamodel-id:: [[stakeholders]]
item-classes:: #[[segment]]
relations:: [[solution (id)]]
weight:: 80


- ## [help](https://go.innbok.com/#/page/stakeholders_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[stakeholders]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  
- ## Topics
    - ### TODO #topic topic/Stakeholder definition
      plastilinn-type:: [[topic]] [[guide-item]]
      innbok-artifact:: [[stakeholders]]
      - {{embed [[topic/Stakeholder definition]]}}
  
    - ### TODO #resource: MIT Entrepreneurship Lesson What Do You Need to Start a Business
      plastilinn-type:: [[resource]] [[guide-item]]
      innbok-artifact:: [[stakeholders]]
        - {{embed [[MIT Entrepreneurship Lesson What Do You Need to Start a Business]]}}
    

