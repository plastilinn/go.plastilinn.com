innbok-type:: internal
metamodel-id:: [[strategy]]
relations:: [[organization goals]] [[mission]] [[vision]]
weight:: 50


- ## [help](https://go.innbok.com/#/page/strategy_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[strategy]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[strategy/Expansion Capability]] [[***]] [[-+]]
    key-weight:: 45
  - #key [[strategy/Cultural Adaptability]] [[**]] [[-+]]
    key-weight:: 40
  - #key [[strategy/Cultural Sensitivity]] [[**]] [[-+]]
    key-weight:: 30
  - #key [[strategy/International Logistics]] [[*]] [[-+]]
    key-weight:: 20
- ## Topics
  

