innbok-type:: internal
metamodel-id:: [[vision]]
relations:: [[business objectives]]
weight:: 50


- ## [help](https://go.innbok.com/#/page/vision_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[vision]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[vision/Realism - Ambition]] [[*]] [[-+]]
    key-weight:: 10
  - #key [[vision/Clarity of Conception]] [[*]] [[-+]]
    key-weight:: 10
- ## Topics
  

