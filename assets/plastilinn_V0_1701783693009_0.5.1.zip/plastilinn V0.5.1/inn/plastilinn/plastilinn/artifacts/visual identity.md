innbok-type:: internal
metamodel-id:: [[visual-identity]]
relations:: [[]]
weight:: 10


- ## [help](https://go.innbok.com/#/page/visual-identity_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[visual identity]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  
- ## Topics
  

