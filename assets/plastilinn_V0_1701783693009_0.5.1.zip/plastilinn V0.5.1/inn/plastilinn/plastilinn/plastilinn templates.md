- ## segment (id) template
  template:: segment (id) template
  template-including-parent:: false
    - ### #item #segment [[<%setInput: name%>]] 
      innbok-item-type:: segment-(id)
      collapsed:: true
      - [help](https://go.innbok.com/#/page/segment-%28id%29%2Finfo)
      - #### #artifact #segment [[<%getInput: name%>]] [[****]] #pending
        - #placeholder
        - #minimal-query
          #+BEGIN_QUERY
          {:query (and [[business info]] "# segment-(id)")
          :breadcrumb-show? false
          }
          #+END_QUERY
      - #### #keys
          - #key [[segment-(id)/Accessibility to decision makers]] [[**]] [[-+]]
            key-weight:: 40
          - #key [[segment-(id)/Market Adaptability]] [[**]] [[-+]]
            key-weight:: 40
          - #key [[segment-(id)/Paying Capacity]] [[**]] [[-+]]
            key-weight:: 35
          - #key [[segment-(id)/Market maturity]] [[**]] [[-+]]
            key-weight:: 30
          - #key [[segment-(id)/Entry barriers]] [[**]] [[-+]]
            key-weight:: 30
          - #key [[segment-(id)/Segment Homogeneity]] [[**]] [[-+]]
            key-weight:: 25
          - #key [[segment-(id)/Exit Barriers]] [[*]] [[-+]]
            key-weight:: 15
          - #key [[segment-(id)/Market Seasonality]] [[*]] [[-+]]
            key-weight:: 10
- ## profile (id) template
  template:: profile (id) template
  template-including-parent:: false
    - ### #item #profile [[<%setInput: name%>]] 
      innbok-item-type:: profile-(id)
      collapsed:: true
      - [help](https://go.innbok.com/#/page/profile-%28id%29%2Finfo)
      - #### #artifact #profile [[<%getInput: name%>]] [[****]] #pending
        - #placeholder
        - #minimal-query
          #+BEGIN_QUERY
          {:query (and [[business info]] "# profile-(id)")
          :breadcrumb-show? false
          }
          #+END_QUERY
      - #### #keys
          - #key [[profile-(id)/Customer Understanding]] [[****]] [[-+]]
            key-weight:: 75
          - #key [[profile-(id)/Customer retention]] [[***]] [[-+]]
            key-weight:: 60
      - ### #item #profile [[<%getInput: name%>]] [[goals]] 
        innbok-item-type:: profile-(id)/goals
        collapsed:: true
        - [help](https://go.innbok.com/#/page/profile-%28id%29%2Fgoals%2Finfo)
        - #### #artifact #profile [[<%getInput: name%>]] [[goals]] [[****]] #pending
          - #goal name
      
          - #minimal-query
            #+BEGIN_QUERY
            {:query (and [[business info]] "# profile-(id)/goals")
            :breadcrumb-show? false
            }
            #+END_QUERY
        - #### #keys
            - #key [[profile-(id)/goals/Addressing a critical problem]] [[****]] [[-+]]
              key-weight:: 80
            - #key [[profile-(id)/goals/Pain perception]] [[****]] [[-+]]
              key-weight:: 70
            - #key [[profile-(id)/goals/Urgency perception]] [[***]] [[-+]]
              key-weight:: 45
            - #key [[profile-(id)/goals/Finantial damage]] [[**]] [[-+]]
              key-weight:: 35
- ## solution (id) template
  template:: solution (id) template
  template-including-parent:: false
    - ### #item #solution [[<%setInput: name%>]] 
      innbok-item-type:: solution-(id)
      collapsed:: true
      - [help](https://go.innbok.com/#/page/solution-%28id%29%2Finfo)
      - #### #artifact #solution [[<%getInput: name%>]] [[***]] #pending
        - #placeholder
        - #minimal-query
          #+BEGIN_QUERY
          {:query (and [[business info]] "# solution-(id)")
          :breadcrumb-show? false
          }
          #+END_QUERY
      - #### #keys
          - #key [[solution-(id)/Product-Market Fit]] [[****]] [[-+]]
            key-weight:: 70
          - #key [[solution-(id)/Solution efficiency]] [[***]] [[-+]]
            key-weight:: 55
          - #key [[solution-(id)/Effective solution]] [[***]] [[-+]]
            key-weight:: 50
          - #key [[solution-(id)/Financial benefits]] [[***]] [[-+]]
            key-weight:: 45
          - #key [[solution-(id)/Ease of Use]] [[***]] [[-+]]
            key-weight:: 45
          - #key [[solution-(id)/Product Quality]] [[**]] [[-+]]
            key-weight:: 40
          - #key [[solution-(id)/Agility]] [[**]] [[-+]]
            key-weight:: 40
          - #key [[solution-(id)/Robust product quality control]] [[**]] [[-+]]
            key-weight:: 35
          - #key [[solution-(id)/Product focus]] [[**]] [[-+]]
            key-weight:: 30
- ## person (id) template
  template:: person (id) template
  template-including-parent:: false
      - ### #item #person [[<%setInput: name%>]] 
        innbok-item-type:: person-(id)
        collapsed:: true
        - [help](https://go.innbok.com/#/page/person-%28id%29%2Finfo)
        - #### #artifact #person [[<%getInput: name%>]] [[****]] #pending
          - #placeholder
          - #minimal-query
            #+BEGIN_QUERY
            {:query (and [[business info]] "# person-(id)")
            :breadcrumb-show? false
            }
            #+END_QUERY
        - #### #keys
            - #key [[person-(id)/Leadership]] [[**]] [[-+]]
              key-weight:: 40
            - #key [[person-(id)/Coachability]] [[**]] [[-+]]
              key-weight:: 30
- ## experiment (id) template
  template:: experiment (id) template
  template-including-parent:: false
      - ### #item [[<%setInput: name%>]] 
        innbok-item-type:: experiment-(id)
        collapsed:: true
        - [help](https://go.innbok.com/#/page/experiment-%28id%29%2Finfo)
        - #### #artifact [[<%getInput: name%>]] [[***]] #pending
          - #placeholder
          - #minimal-query
            #+BEGIN_QUERY
            {:query (and [[business info]] "# experiment-(id)")
            :breadcrumb-show? false
            }
            #+END_QUERY
        - #### #keys
            

