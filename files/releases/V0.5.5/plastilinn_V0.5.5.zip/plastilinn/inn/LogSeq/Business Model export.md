## 1 Copy content
	- [[plastilinn/Copy block]] How to copy this content
	- #inn-edit
		- {{embed [[business info - impulsar.ai]]}}
- ## 2 Paste it on a markdown editor
	- such as https://stackedit.io/app#
- ## 3 Copy paste formatted content
- ## Export model
	- [[Export to text]]