# [[Lean Canvas whiteboard]]
id:: 6572ffb1-c285-4c9c-b612-d8ec7e434bab
	- {{embed [[Lean Canvas whiteboard]]}}
- ## How to use the Lean Canvas
  id:: 659ecca9-fd7d-412c-8caa-2d10dc60a724
	- Open the [[Lean Canvas whiteboard]] in the main window (click on the link)
	- Open the [[Lean Canvas]] at the right panel (SHIF+CLICK)
- ## Customer Segments
  page-type:: #{"artifact"}
  id:: 6525869c-b421-4f6d-9d03-41902c06692d
	- Define the target customer segments you want to serve.
	  id:: 6572ffb1-15cf-4559-a328-cc36291afa05
	- {{embed [[profile (id)]]}}
- ## Problem
  id:: 6441276a-8ab2-4123-90d5-489ff9d6274d
	- List the top three problems your target customers face.
	- {{embed [[profile (id)/goals]]}}
- ## Unique Value Proposition
  collapsed:: true
	- Describe the unique and compelling value you offer to your customers that sets you apart from the competition.
	- {{embed [[profile (id)/value proposition]]}}
- ## Solution
  collapsed:: true
	- Outline the proposed solutions to the top problems you've identified.
	- {{embed [[solution 1 renamed]]}}
- ## Channels
  collapsed:: true
	- List the channels you'll use to reach your target customers.
	- {{embed [[profile (id)/channels]]}}
- ## Revenue Streams
  collapsed:: true
	- Identify the ways your business will generate revenue.
	- {{embed [[revenue lines]]}}
- ## Cost Structure
	- Enumerate the main costs associated with your business model.
	- {{embed [[cost lines]]}}
- ## Key Metrics
  id:: 6441276a-5cb8-41b3-9fe4-f1f32a1be961
	- Define the key metrics that will help you track your business's success.
	- {{embed [[metrics]]}}
- ## Unfair Advantage
  id:: 6525869c-b4f6-4025-b755-0f8cdfcd43bb
	- Describe any unfair advantage you may have that cannot be easily copied or bought by competitors.
	- {{embed [[unfair advantage]]}}
	  id:: 6441276a-b061-4bf5-88a3-effe42e37bd4
- ## Image
	- {{embed [[Lean Canvas image]]}}