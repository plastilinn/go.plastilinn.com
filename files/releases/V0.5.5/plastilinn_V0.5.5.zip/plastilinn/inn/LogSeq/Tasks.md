icon:: ⛏️

- #minimal-query
  #+BEGIN_QUERY
  { :query (and (task NOW LATER DOING IN-PROGRESS TODO WAIT WAITING) [[business info - DeLorean Time Machines]] )
  }
  #+END_QUERY