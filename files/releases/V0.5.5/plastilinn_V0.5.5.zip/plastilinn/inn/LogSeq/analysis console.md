icon:: 🔑

- #🗂️ #analysis [keys (weight)]([[keys (weight)]]) [keys (rating)]([[keys (rating)]]) [keys (risk)]([[keys (risk)]])
-