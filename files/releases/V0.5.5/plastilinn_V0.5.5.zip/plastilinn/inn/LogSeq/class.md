public:: true
icon:: 🌐

- {{query (page-property :innbok-type [[class]])}}
  query-sort-by:: updated-at
  query-sort-desc:: false
  query-properties:: [:innbok-type :alias :title :page :icon]
-