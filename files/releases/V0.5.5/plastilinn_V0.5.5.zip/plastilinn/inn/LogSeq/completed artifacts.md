- {{embed [[plastilinn console menu]]}}
- #minimal-query
  #+BEGIN_QUERY
  { :query (and [[business info]] (not "#off"))
  :breadcrumb-show? false
  }
  #+END_QUERY