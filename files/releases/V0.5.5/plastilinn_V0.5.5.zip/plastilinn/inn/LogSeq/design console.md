icon:: 🖌️

- #🗂️ #design [business info]([[business info]]) [index]([[business model - index]]) [items]([[business model - items]]) [pending]([[pending artifacts]]) [completed]([[completed artifacts]])