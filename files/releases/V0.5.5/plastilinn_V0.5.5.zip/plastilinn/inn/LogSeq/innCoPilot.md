icon:: 🤖

- https://chat.openai.com/g/g-BExd1ryTG-inncopilot-business-model-advisor
	- https://chat.openai.com/g/g-BExd1ryTG-inncopilot-business-model-advisor