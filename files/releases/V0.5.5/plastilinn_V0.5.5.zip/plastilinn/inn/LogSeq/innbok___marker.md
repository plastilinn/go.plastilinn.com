- {{query (and (namespace [[innbok/marker]]) (sort-by created-at desc))}}
  query-properties:: [:page :icon :alias]