icon:: 🔑

- {{query (property :innbok-key-rating)}}
  query-table:: true