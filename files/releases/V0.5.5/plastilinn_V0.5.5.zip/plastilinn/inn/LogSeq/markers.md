color:: red
icon:: 🔖

- query-properties:: [:alias :icon]
  #+BEGIN_QUERY
  { :query (namespace [[innbok/markers]])
  :breadcrumb-show? false
  }
  #+END_QUERY
- query-properties:: [:page :icon :alias]
- {{embed [[innBoK/markers]]}}
- #+BEGIN_TIP
  [[shiftclick on any of the markers above to open it in the right panel]]
  #+END_TIP
-