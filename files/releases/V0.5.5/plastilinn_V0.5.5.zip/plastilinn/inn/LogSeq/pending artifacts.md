- {{embed [[plastilinn console menu]]}}
- #minimal-query
  query-table:: false
  #+BEGIN_QUERY
  { :query (and [[business info]] "#off")
  :breadcrumb-show? false
  }
  #+END_QUERY