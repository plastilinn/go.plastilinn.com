icon:: 📈

- {{embed [[plastilinn console menu]]}}
-