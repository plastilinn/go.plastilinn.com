public:: true

- Continuous Business Model Improvement powered by AI
- # how to
	- Regístrate para descargar plastilinn
	- Descarga el fichero zip y extráelo en la ubicación que prefieras (y que recuerdes)
	- Entra en https://demo.logseq.com/
	- Pulsa en el botón "añadir grafo" arriba a la derecha
	- Pulsa en el botón "escoger una carpeta"
	-