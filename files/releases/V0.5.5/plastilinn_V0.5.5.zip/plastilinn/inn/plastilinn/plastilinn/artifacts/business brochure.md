innbok-type:: internal
metamodel-id:: [[business-brochure]]
relations:: [[]]
weight:: 20


- ## [help](https://go.innbok.com/#/page/business-brochure_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[business brochure]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  
- ## Topics
  

