innbok-type:: internal
metamodel-id:: [[business-objectives]]
relations:: [[opportunity]]
weight:: 70


- ## [help](https://go.innbok.com/#/page/business-objectives_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[business objectives]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[business-objectives/Ambitious Goals]] [[**]] [[-+]]
    key-weight:: 30
- ## Topics
  

