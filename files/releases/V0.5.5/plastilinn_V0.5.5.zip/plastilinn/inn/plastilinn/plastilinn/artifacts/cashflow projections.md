innbok-type:: internal
metamodel-id:: [[cashflow-projections]]
relations:: [[]]
weight:: 30


- ## [help](https://go.innbok.com/#/page/cashflow-projections_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[cashflow projections]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[cashflow-projections/Positive Cash Flow]] [[***]] [[-+]]
    key-weight:: 55
- ## Topics
  

