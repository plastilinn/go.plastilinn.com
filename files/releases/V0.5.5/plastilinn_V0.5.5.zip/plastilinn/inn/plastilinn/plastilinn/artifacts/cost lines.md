innbok-type:: internal
metamodel-id:: [[cost-lines]]
item-classes:: #[[cost]]
relations:: [[activitiy list]]
weight:: 40


- ## [help](https://go.innbok.com/#/page/cost-lines_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[cost lines]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[cost-lines/Cost Structure]] [[**]] [[-+]]
    key-weight:: 35
  - #key [[cost-lines/Cost optimization]] [[**]] [[-+]]
    key-weight:: 30
- ## Topics
  

