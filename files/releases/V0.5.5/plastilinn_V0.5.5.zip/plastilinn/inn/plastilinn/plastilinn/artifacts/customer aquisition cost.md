innbok-type:: internal
metamodel-id:: [[customer-aquisition-cost]]
relations:: [[]]
weight:: 60


- ## [help](https://go.innbok.com/#/page/customer-aquisition-cost_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[customer aquisition cost]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  
- ## Topics
  

