innbok-type:: internal
metamodel-id:: [[experiment-(id)]]
relations:: [[]] [[risk list]]
weight:: 50


- ## [help](https://go.innbok.com/#/page/experiment-%28id%29_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[experiment (id)]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  
- ## Topics
  

