innbok-type:: internal
metamodel-id:: [[finance]]
relations:: [[business]] [[activitiy list]]
weight:: 50


- ## [help](https://go.innbok.com/#/page/finance_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[finance]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[finance/Profitability]] [[***]] [[-+]]
    key-weight:: 60
  - #key [[finance/Gross margins]] [[***]] [[-+]]
    key-weight:: 60
  - #key [[finance/Financial Management]] [[***]] [[-+]]
    key-weight:: 50
  - #key [[finance/Finantial needs]] [[***]] [[-+]]
    key-weight:: 45
  - #key [[finance/Proactive tax planning and compliance]] [[*]] [[-+]]
    key-weight:: 15
  - #key [[finance/Currency risk management]] [[*]] [[-+]]
    key-weight:: 10
- ## Topics
  

