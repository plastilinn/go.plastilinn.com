innbok-type:: internal
metamodel-id:: [[finantial-projections]]
relations:: [[]]
weight:: 20


- ## [help](https://go.innbok.com/#/page/finantial-projections_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[finantial projections]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[finantial-projections/Projections]] [[**]] [[-+]]
    key-weight:: 40
- ## Topics
  

