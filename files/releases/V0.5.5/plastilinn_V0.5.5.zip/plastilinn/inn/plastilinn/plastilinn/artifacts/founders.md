innbok-type:: internal
metamodel-id:: [[founders]]
item-classes:: #[[person]]
relations:: [[]]
weight:: 70


- ## [help](https://go.innbok.com/#/page/founders_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[founders]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[founders/Founder's capacity]] [[****]] [[-+]]
    key-weight:: 65
  - #key [[founders/Founder's commitment]] [[***]] [[-+]]
    key-weight:: 55
  - #key [[founders/Leadership Skills]] [[**]] [[-+]]
    key-weight:: 40
  - #key [[founders/Attitude for improvement]] [[**]] [[-+]]
    key-weight:: 30
  - #key [[founders/Founder's circumstances]] [[*]] [[-+]]
    key-weight:: 20
- ## Topics
  

