innbok-type:: internal
metamodel-id:: [[legal-issues]]
relations:: [[]]
weight:: 40


- ## [help](https://go.innbok.com/#/page/legal-issues_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[legal issues]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  
- ## Topics
  

