innbok-type:: internal
metamodel-id:: [[metric-list]]
item-classes:: #[[metric]]
relations:: [[business]] [[activitiy list]]
weight:: 50


- ## [help](https://go.innbok.com/#/page/metric-list_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[metric list]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[metric-list/Monitoring Key Metrics]] [[***]] [[-+]]
    key-weight:: 50
  - #key [[metric-list/Data Analysis Tools]] [[*]] [[-+]]
    key-weight:: 20
- ## Topics
  

