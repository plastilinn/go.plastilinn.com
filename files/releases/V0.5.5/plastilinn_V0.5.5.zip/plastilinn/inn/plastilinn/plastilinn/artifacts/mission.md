innbok-type:: internal
metamodel-id:: [[mission]]
relations:: [[business objectives]]
weight:: 60


- ## [help](https://go.innbok.com/#/page/mission_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[mission]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[mission/Realism - Ambition]] [[**]] [[-+]]
    key-weight:: 30
  - #key [[mission/Clarity of Conception]] [[*]] [[-+]]
    key-weight:: 20
- ## Topics
  

