innbok-type:: internal
metamodel-id:: [[naming]]
relations:: [[]]
weight:: 30


- ## [help](https://go.innbok.com/#/page/naming_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[naming]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[naming/Pronunciation Ease]] [[*]] [[-+]]
    key-weight:: 20
  - #key [[naming/Phonetic Consistency]] [[*]] [[-+]]
    key-weight:: 10
  - #key [[naming/Spelling from Pronunciation]] [[*]] [[-+]]
    key-weight:: 10
  - #key [[naming/Negative Connotations]] [[*]] [[-+]]
    key-weight:: 10
- ## Topics
  

