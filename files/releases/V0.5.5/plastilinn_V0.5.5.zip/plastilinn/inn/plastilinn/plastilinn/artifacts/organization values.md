innbok-type:: internal
metamodel-id:: [[organization-values]]
relations:: [[business objectives]]
weight:: 50


- ## [help](https://go.innbok.com/#/page/organization-values_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[organization values]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  
- ## Topics
  

