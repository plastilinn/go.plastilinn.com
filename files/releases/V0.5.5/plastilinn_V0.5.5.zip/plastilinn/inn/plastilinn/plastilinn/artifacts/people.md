innbok-type:: internal
metamodel-id:: [[people]]
item-classes:: #[[person]]
relations:: [[team]]
weight:: 70


- ## [help](https://go.innbok.com/#/page/people_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[people]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[people/Receptiveness to Feedback]] [[**]] [[-+]]
    key-weight:: 40
  - #key [[people/Competency scope]] [[**]] [[-+]]
    key-weight:: 40
  - #key [[people/Relevant experience]] [[**]] [[-+]]
    key-weight:: 30
  - #key [[people/Market experience]] [[**]] [[-+]]
    key-weight:: 25
  - #key [[people/Skills and expectations overlap]] [[**]] [[-+]]
    key-weight:: 25
  - #key [[people/Vertical experience]] [[*]] [[-+]]
    key-weight:: 15
  - #key [[people/Experience working together]] [[*]] [[-+]]
    key-weight:: 10
- ## Topics
  

