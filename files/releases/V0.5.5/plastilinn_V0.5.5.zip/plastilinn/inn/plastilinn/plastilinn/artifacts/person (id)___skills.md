innbok-type:: internal
metamodel-id:: [[person-(id)/skills]]
item-classes:: #[[skill]]
relations:: [[person (id)]] [[solution (id)]]
weight:: 50


- ## [help](https://go.innbok.com/#/page/person-%28id%29%2Fskills_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[person (id)/skills]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  
- ## Topics
  

