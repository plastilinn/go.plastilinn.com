innbok-type:: internal
metamodel-id:: [[pitch]]
relations:: [[]]
weight:: 20


- ## [help](https://go.innbok.com/#/page/pitch_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[pitch]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  
- ## Topics
  

