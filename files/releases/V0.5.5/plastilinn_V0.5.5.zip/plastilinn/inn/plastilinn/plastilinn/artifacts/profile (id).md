innbok-type:: internal
metamodel-id:: [[profile-(id)]]
relations:: [[]]
weight:: 70


- ## [help](https://go.innbok.com/#/page/profile-%28id%29_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[profile (id)]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[profile-(id)/Customer Understanding]] [[****]] [[-+]]
    key-weight:: 75
  - #key [[profile-(id)/Customer retention]] [[***]] [[-+]]
    key-weight:: 60
- ## Topics
  

