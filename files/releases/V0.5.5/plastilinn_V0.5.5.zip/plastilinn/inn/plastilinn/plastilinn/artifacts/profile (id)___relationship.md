innbok-type:: internal
metamodel-id:: [[profile-(id)/relationship]]
item-classes:: #[[relationship]]
relations:: [[profile (id)]] [[profile (id)/channels]]
weight:: 20


- ## [help](https://go.innbok.com/#/page/profile-%28id%29%2Frelationship_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[profile (id)/relationship]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[profile-(id)/relationship/Customer satisfaction]] [[****]] [[-+]]
    key-weight:: 70
- ## Topics
  

