innbok-type:: internal
metamodel-id:: [[profile-(id)/transactions]]
item-classes:: #[[transaction]]
relations:: [[profile (id)]] [[solution id___offerings]] [[profile id___assets]]
weight:: 20


- ## [help](https://go.innbok.com/#/page/profile-%28id%29%2Ftransactions_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[profile (id)/transactions]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  
- ## Topics
  

