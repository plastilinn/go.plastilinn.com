innbok-type:: internal
metamodel-id:: [[profile-(id)/value-proposition]]
item-classes:: #[[value]]
relations:: [[profile (id)]] [[profile (id)/goals]] [[solution list]]
weight:: 50


- ## [help](https://go.innbok.com/#/page/profile-%28id%29%2Fvalue-proposition_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[profile (id)/value proposition]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[profile-(id)/value-proposition/Solution to a Problem]] [[****]] [[-+]]
    key-weight:: 70
  - #key [[profile-(id)/value-proposition/Potential value]] [[**]] [[-+]]
    key-weight:: 40
- ## Topics
  

