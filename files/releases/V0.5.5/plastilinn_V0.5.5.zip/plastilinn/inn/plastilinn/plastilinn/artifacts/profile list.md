innbok-type:: internal
metamodel-id:: [[profile-list]]
relations:: [[]]
weight:: 60


- ## [help](https://go.innbok.com/#/page/profile-list_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[profile list]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  
- ## Topics
  

