innbok-type:: internal
metamodel-id:: [[references]]
relations:: [[]]
weight:: 0


- ## [help](https://go.innbok.com/#/page/references_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[references]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  
- ## Topics
  
a[data-ref="*"] { position: relative; padding-left: 25px; } a[data-ref="*"]::before { content: "⭐"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="**"] { position: relative; padding-left: 25px; } a[data-ref="**"]::before { content: "⭐"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="***"] { position: relative; padding-left: 25px; } a[data-ref="***"]::before { content: "⭐"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="****"] { position: relative; padding-left: 25px; } a[data-ref="****"]::before { content: "⭐"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="*****"] { position: relative; padding-left: 25px; } a[data-ref="*****"]::before { content: "⭐"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="?"] { position: relative; padding-left: 25px; } a[data-ref="?"]::before { content: "☁️"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="??"] { position: relative; padding-left: 25px; } a[data-ref="??"]::before { content: "☁️"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="???"] { position: relative; padding-left: 25px; } a[data-ref="???"]::before { content: "☁️"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="????"] { position: relative; padding-left: 25px; } a[data-ref="????"]::before { content: "☁️"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="?????"] { position: relative; padding-left: 25px; } a[data-ref="?????"]::before { content: "☁️"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="="] { position: relative; padding-left: 25px; } a[data-ref="="]::before { content: "✅"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="=="] { position: relative; padding-left: 25px; } a[data-ref="=="]::before { content: "✅"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="==="] { position: relative; padding-left: 25px; } a[data-ref="==="]::before { content: "✅"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="===="] { position: relative; padding-left: 25px; } a[data-ref="===="]::before { content: "✅"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="====="] { position: relative; padding-left: 25px; } a[data-ref="====="]::before { content: "✅"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="+"] { position: relative; padding-left: 25px; } a[data-ref="+"]::before { content: "🔋"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="++"] { position: relative; padding-left: 25px; } a[data-ref="++"]::before { content: "🔋"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="+++"] { position: relative; padding-left: 25px; } a[data-ref="+++"]::before { content: "🔋"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="++++"] { position: relative; padding-left: 25px; } a[data-ref="++++"]::before { content: "🔋"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="+++++"] { position: relative; padding-left: 25px; } a[data-ref="+++++"]::before { content: "🔋"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="-"] { position: relative; padding-left: 25px; } a[data-ref="-"]::before { content: "🪫"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="--"] { position: relative; padding-left: 25px; } a[data-ref="--"]::before { content: "🪫"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="---"] { position: relative; padding-left: 25px; } a[data-ref="---"]::before { content: "🪫"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="----"] { position: relative; padding-left: 25px; } a[data-ref="----"]::before { content: "🪫"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="-----"] { position: relative; padding-left: 25px; } a[data-ref="-----"]::before { content: "🪫"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="@"] { position: relative; padding-left: 25px; } a[data-ref="@"]::before { content: "🚩"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="@@"] { position: relative; padding-left: 25px; } a[data-ref="@@"]::before { content: "🚩"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="@@@"] { position: relative; padding-left: 25px; } a[data-ref="@@@"]::before { content: "🚩"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="@@@@"] { position: relative; padding-left: 25px; } a[data-ref="@@@@"]::before { content: "🚩"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="@@@@@"] { position: relative; padding-left: 25px; } a[data-ref="@@@@@"]::before { content: "🚩"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="p"] { position: relative; padding-left: 25px; } a[data-ref="p"]::before { content: "🗓️"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="pp"] { position: relative; padding-left: 25px; } a[data-ref="pp"]::before { content: "🗓️"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="ppp"] { position: relative; padding-left: 25px; } a[data-ref="ppp"]::before { content: "🗓️"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="pppp"] { position: relative; padding-left: 25px; } a[data-ref="pppp"]::before { content: "🗓️"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="ppppp"] { position: relative; padding-left: 25px; } a[data-ref="ppppp"]::before { content: "🗓️"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="!"] { position: relative; padding-left: 25px; } a[data-ref="!"]::before { content: "🔥"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="!!"] { position: relative; padding-left: 25px; } a[data-ref="!!"]::before { content: "🔥"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="!!!"] { position: relative; padding-left: 25px; } a[data-ref="!!!"]::before { content: "🔥"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="!!!!"] { position: relative; padding-left: 25px; } a[data-ref="!!!!"]::before { content: "🔥"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }
a[data-ref="!!!!!"] { position: relative; padding-left: 25px; } a[data-ref="!!!!!"]::before { content: "🔥"; position: absolute; left: 0; top: 50%; transform: translateY(-50%); font-size: 15px; }

