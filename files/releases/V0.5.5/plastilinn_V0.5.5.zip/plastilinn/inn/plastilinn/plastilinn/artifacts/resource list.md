innbok-type:: internal
metamodel-id:: [[resource-list]]
item-classes:: #[[asset]]
relations:: [[business]] [[operations]]
weight:: 40


- ## [help](https://go.innbok.com/#/page/resource-list_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[resource list]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[resource-list/Resilient supply chain management]] [[***]] [[-+]]
    key-weight:: 50
  - #key [[resource-list/Financial needs]] [[**]] [[-+]]
    key-weight:: 40
- ## Topics
  

