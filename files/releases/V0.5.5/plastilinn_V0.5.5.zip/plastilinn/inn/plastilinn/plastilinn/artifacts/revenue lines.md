innbok-type:: internal
metamodel-id:: [[revenue-lines]]
item-classes:: #[[revenue]]
relations:: [[solution (id)/offerings]]
weight:: 50


- ## [help](https://go.innbok.com/#/page/revenue-lines_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[revenue lines]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[revenue-lines/Revenue Sources]] [[****]] [[-+]]
    key-weight:: 65
  - #key [[revenue-lines/Diversified revenue streams]] [[**]] [[-+]]
    key-weight:: 40
- ## Topics
  

