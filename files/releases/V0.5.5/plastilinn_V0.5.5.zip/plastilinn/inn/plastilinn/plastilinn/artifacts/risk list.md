innbok-type:: internal
metamodel-id:: [[risk-list]]
item-classes:: #[[risk]]
relations:: [[]]
weight:: 90


- ## [help](https://go.innbok.com/#/page/risk-list_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[risk list]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[risk-list/Risk Identification]] [[***]] [[-+]]
    key-weight:: 50
  - #key [[risk-list/Crisis Management]] [[**]] [[-+]]
    key-weight:: 30
  - #key [[risk-list/Contingency Plans]] [[*]] [[-+]]
    key-weight:: 20
- ## Topics
  - ### TODO #topic topic/Modelo de negocio/Ciclo de modelado de negocio/Análisis/Riesgos
    plastilinn-type:: [[topic]] [[guide-item]]
    innbok-artifact:: [[risk-list]]
    - {{embed [[topic/Modelo de negocio/Ciclo de modelado de negocio/Análisis/Riesgos]]}}
  
  - ### TODO #topic topic/Modelo de negocio/Ciclo de modelado de negocio/Análisis/Gestión de riesgos
    plastilinn-type:: [[topic]] [[guide-item]]
    innbok-artifact:: [[risk-list]]
    - {{embed [[topic/Modelo de negocio/Ciclo de modelado de negocio/Análisis/Gestión de riesgos]]}}
  

