innbok-type:: internal
metamodel-id:: [[segment-(id)]]
relations:: [[]]
weight:: 70


- ## [help](https://go.innbok.com/#/page/segment-%28id%29_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[segment (id)]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[segment-(id)/Accessibility to decision makers]] [[**]] [[-+]]
    key-weight:: 40
  - #key [[segment-(id)/Market Adaptability]] [[**]] [[-+]]
    key-weight:: 40
  - #key [[segment-(id)/Paying Capacity]] [[**]] [[-+]]
    key-weight:: 35
  - #key [[segment-(id)/Market maturity]] [[**]] [[-+]]
    key-weight:: 30
  - #key [[segment-(id)/Entry barriers]] [[**]] [[-+]]
    key-weight:: 30
  - #key [[segment-(id)/Segment Homogeneity]] [[**]] [[-+]]
    key-weight:: 25
  - #key [[segment-(id)/Exit Barriers]] [[*]] [[-+]]
    key-weight:: 15
  - #key [[segment-(id)/Market Seasonality]] [[*]] [[-+]]
    key-weight:: 10
- ## Topics
  

