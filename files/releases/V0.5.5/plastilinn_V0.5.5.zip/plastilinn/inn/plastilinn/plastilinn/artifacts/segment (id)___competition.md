innbok-type:: internal
metamodel-id:: [[segment-(id)/competition]]
item-classes:: #[[stakeholder]]
relations:: [[segment (id)]] [[]]
weight:: 40


- ## [help](https://go.innbok.com/#/page/segment-%28id%29%2Fcompetition_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[segment (id)/competition]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[segment-(id)/competition/Competitive Advantage]] [[****]] [[-+]]
    key-weight:: 65
  - #key [[segment-(id)/competition/Competitive landscape]] [[***]] [[-+]]
    key-weight:: 50
  - #key [[segment-(id)/competition/Competitor Analysis]] [[**]] [[-+]]
    key-weight:: 40
- ## Topics
  

