innbok-type:: internal
metamodel-id:: [[segment-(id)/partners]]
item-classes:: #[[stakeholder]]
relations:: [[segment (id)]] [[solution (id)]]
weight:: 20


- ## [help](https://go.innbok.com/#/page/segment-%28id%29%2Fpartners_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[segment (id)/partners]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[segment-(id)/partners/Strategic Alliances]] [[**]] [[-+]]
    key-weight:: 40
  - #key [[segment-(id)/partners/Supplier Relationships]] [[**]] [[-+]]
    key-weight:: 30
  - #key [[segment-(id)/partners/Networking]] [[**]] [[-+]]
    key-weight:: 25
- ## Topics
  

