innbok-type:: internal
metamodel-id:: [[solution-(id)/components]]
relations:: [[solution (id)]] [[solution id___category]] [[solution id___features]] [[solution id___roadmap]]
weight:: 20


- ## [help](https://go.innbok.com/#/page/solution-%28id%29%2Fcomponents_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[solution (id)/components]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[solution-(id)/components/Appropriate Solution Components]] [[*]] [[-+]]
    key-weight:: 20
- ## Topics
  

