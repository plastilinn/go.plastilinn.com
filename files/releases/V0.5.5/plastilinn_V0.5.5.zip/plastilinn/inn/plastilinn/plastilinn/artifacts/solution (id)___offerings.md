innbok-type:: internal
metamodel-id:: [[solution-(id)/offerings]]
item-classes:: #[[offering]]
relations:: [[solution (id)]] [[solution list]] [[solution (id)/features]]
weight:: 40


- ## [help](https://go.innbok.com/#/page/solution-%28id%29%2Fofferings_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[solution (id)/offerings]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[solution-(id)/offerings/Solutions offerings structure]] [[**]] [[-+]]
    key-weight:: 40
- ## Topics
  

