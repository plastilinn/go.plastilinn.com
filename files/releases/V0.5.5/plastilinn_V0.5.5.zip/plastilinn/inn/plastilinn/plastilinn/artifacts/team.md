innbok-type:: internal
metamodel-id:: [[team]]
relations:: [[]]
weight:: 70


- ## [help](https://go.innbok.com/#/page/team_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[team]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[team/Team Skills]] [[****]] [[-+]]
    key-weight:: 70
  - #key [[team/Team Commitment]] [[***]] [[-+]]
    key-weight:: 60
  - #key [[team/Adaptability to Change]] [[***]] [[-+]]
    key-weight:: 55
  - #key [[team/Team alignment]] [[***]] [[-+]]
    key-weight:: 50
  - #key [[team/Effective talent acquisition and retention]] [[***]] [[-+]]
    key-weight:: 50
  - #key [[team/Culture of Experimentation]] [[***]] [[-+]]
    key-weight:: 50
  - #key [[team/Human Resource Management]] [[***]] [[-+]]
    key-weight:: 45
  - #key [[team/Talent Retention]] [[**]] [[-+]]
    key-weight:: 35
  - #key [[team/Work Environment]] [[**]] [[-+]]
    key-weight:: 30
  - #key [[team/Team composition]] [[**]] [[-+]]
    key-weight:: 30
  - #key [[team/Benefits and Compensation]] [[*]] [[-+]]
    key-weight:: 20
  - #key [[team/Employee Development]] [[*]] [[-+]]
    key-weight:: 20
- ## Topics
  

