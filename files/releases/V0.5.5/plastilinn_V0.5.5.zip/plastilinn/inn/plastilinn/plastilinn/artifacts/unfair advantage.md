innbok-type:: internal
metamodel-id:: [[unfair-advantage]]
relations:: [[]]
weight:: 50


- ## [help](https://go.innbok.com/#/page/unfair-advantage_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[unfair advantage]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[unfair-advantage/Differentiation and competitive advantage]] [[***]] [[-+]]
    key-weight:: 60
  - #key [[unfair-advantage/Relevance of the Advantage]] [[***]] [[-+]]
    key-weight:: 55
- ## Topics
  

