innbok-type:: internal
metamodel-id:: [[unit-economics]]
relations:: [[]]
weight:: 40


- ## [help](https://go.innbok.com/#/page/unit-economics_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[unit economics]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  - #key [[unit-economics/Cost management and pricing strategies]] [[**]] [[-+]]
    key-weight:: 40
- ## Topics
  

