innbok-type:: internal
metamodel-id:: [[validation]]
relations:: [[]]
weight:: 90


- ## [help](https://go.innbok.com/#/page/validation_info)
  background-color:: blue
- #minimal-query
  #+BEGIN_QUERY
  {:query [:find (pull ?b [*])
   :in $ ?keyword [?title ...]
     :where
       [?p :block/original-name ?title]
       [?b :block/page ?p]
       [?b :block/content ?c]
       [(clojure.string/includes? ?c ?keyword)]]
   :inputs ["# [[validation]]" ["business info"]]
   }
   #+END_QUERY
- ## Keys
  
- ## Topics
  - ### TODO #topic topic/Modelo de negocio/Ciclo de modelado de negocio/Validación
    plastilinn-type:: [[topic]] [[guide-item]]
    innbok-artifact:: [[validation]]
    - {{embed [[topic/Modelo de negocio/Ciclo de modelado de negocio/Validación]]}}
  
  - ### TODO #topic topic/Modelo de negocio/Ciclo de modelado de negocio/Validación/Feedback
    plastilinn-type:: [[topic]] [[guide-item]]
    innbok-artifact:: [[validation]]
    - {{embed [[topic/Modelo de negocio/Ciclo de modelado de negocio/Validación/Feedback]]}}
  
  - ### TODO #topic topic/Modelo de negocio/Ciclo de modelado de negocio/Validación/Método científico
    plastilinn-type:: [[topic]] [[guide-item]]
    innbok-artifact:: [[validation]]
    - {{embed [[topic/Modelo de negocio/Ciclo de modelado de negocio/Validación/Método científico]]}}
  
  

